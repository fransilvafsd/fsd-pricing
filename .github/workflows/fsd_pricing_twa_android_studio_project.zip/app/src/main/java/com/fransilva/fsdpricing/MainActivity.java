
package com.fransilva.fsdpricing;
import android.os.Bundle;
import androidx.browser.trusted.TrustedWebActivityLauncherActivity;
public class MainActivity extends TrustedWebActivityLauncherActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
